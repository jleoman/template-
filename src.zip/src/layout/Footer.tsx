function Footer() {
  return (
    <footer className="admin__footer">
      Footer
    </footer>
  )
}

export default Footer