import { Routes, Route } from "react-router-dom"

import SidebarCompact from "../components/sidebar/compact/SidebarCompact"
import SidebarIconPanel from "../components/sidebar/Icon-panel/SidebarIconPanel"
import SidebarClassic from "../components/sidebar/classic/ClassicSidebar"

import Dashboard from "../pages/dashboard/Dashboard"
import DocumentRequests from "../pages/document-requests/DocumentRequests"
import Approvals from "../pages/approvals/Approvals"
import Repository from "../pages/repository/Repository"
import Tracking from "../pages/tracking/Tracking"

const AdminLayout = () => {

  return (

    <div className="admin-layout">

      <SidebarCompact/>

      <div className="admin-content">

        <Routes>

          <Route path="/" element={<Dashboard />} />

          <Route path="/dashboard" element={<Dashboard />} />

          <Route path="/requests" element={<DocumentRequests />} />

          <Route path="/approvals" element={<Approvals />} />

          <Route path="/repository" element={<Repository />} />

          <Route path="/tracking" element={<Tracking />} />

        </Routes>

      </div>

    </div>

  )

}

export default AdminLayout