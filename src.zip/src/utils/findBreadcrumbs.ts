import type { SidebarItem } from "../components/sidebar/sidebar-v4/sidebar.types"

export function findBreadcrumbs(
  items: SidebarItem[],
  path: string,
  parents: SidebarItem[] = []
): SidebarItem[] | null {

  for (const item of items) {

    if (item.path === path) {
      return [...parents, item]
    }

    if (item.children) {
      const result = findBreadcrumbs(
        item.children,
        path,
        [...parents, item]
      )

      if (result) return result
    }

  }

  return null
}