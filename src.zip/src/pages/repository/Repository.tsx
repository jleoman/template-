import BreadcrumbHeader from "../../components/breadcrumb/Breadcrumb"

export default function Repository() {

  return (

    <div className="page-container">

      <BreadcrumbHeader
        title="respository"
        breadcrumb={["Dashboard", "respository"]}
      />

      <div>Repository Page</div>

    </div>

  )

}