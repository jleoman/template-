import Breadcrumb from "../../components/breadcrumb/Breadcrumb"
import PageHeader from "../../components/page-header/PageHeader"

export default function Dashboard(){
  
  return(

     <div className="page-container">
 
        <Breadcrumb items={["Dashboard", "Document Requests"]} />
 
        <PageHeader
           title="Document Requests"
        
         />
  </div>

  )

}