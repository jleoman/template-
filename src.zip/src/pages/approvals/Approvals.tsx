import BreadcrumbHeader from "../../components/breadcrumb/Breadcrumb"

export default function Approvals() {

  return (

    <div className="page-container">

      <BreadcrumbHeader
        title="Approvals"
        breadcrumb={["Dashboard", "Approvals"]}
      />

      <div>Approvals Page</div>

    </div>

  )

}