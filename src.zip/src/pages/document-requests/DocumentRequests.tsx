import Breadcrumb from "../../components/breadcrumb/Breadcrumb"
import PageHeader from "../../components/page-header/PageHeader"
import Tabsunderline from "../../components/tabs/underline/TabsUnderline"

import { useState } from "react"
import Table from "../../components/table"
import PageSlider from "../../components/page-slider/PageSlider"
import PageSliderHeader from "../../components/page-slider/PageSliderHeader"
import PageSliderBody from "../../components/page-slider/PageSliderBody"
import FormRow from "../../components/form/FormRow"
import FormField from "../../components/form/FormField"
import Input from "../../components/form/Input"
import ComboBox from "../../components/form/ComboBox"
import Textarea from "../../components/form/Textarea"
import Select from "../../components/form/Select"
type Option = {
  label: string
  value: string
}
export default function DocumentRequests(){
  const [openSlider, setOpenSlider] = useState(false)
  const [borrower, setBorrower] = useState("")
  const [remark, setRemark] = useState("")
  const [country, setCountry] = useState("")
  const [date, setDate] = useState("")
  const [errors, setErrors] = useState<any>({})
  const [proposal, setProposal] = useState<Option | null>(null)
  const [isFetching, setIsFetching] = useState(false)
  const handleDelete = (row: any) => {console.log("Delete clicked for:", row)
}


  const validate = () => {
  const newErrors: any = {}

  if (!borrower) newErrors.borrower = "Borrower is required"
  if (!proposal) newErrors.proposal = "Proposal is required"
  if (!date) newErrors.date = "Date is required"
  if (!country) newErrors.country = "Country is required"

  setErrors(newErrors)

  return Object.keys(newErrors).length === 0
}

const handleSave = () => {
  if (!validate()) return

  console.log({
    borrower,
    proposal,
    date,
    country,
  })
}

const dashboardTabs = [
  { label: "All", value: "all" },
  { label: "News", value: "news" },
  { label: "Trending", value: "trending" },
];

 // Columns (same as before)
  const columns = [
    { key: "id", title: "ID", width: "80px", sortable: true },
    { key: "name", title: "Name", sortable: true },
    { key: "email", title: "Email", sortable: true },
     { key: "user", title: "User", sortable: true },
    { key: "status", title: "Status", render: (v: string) => (
      <span className={`status-badge status-${v.toLowerCase()}`}>{v}</span>
    )}
  ]

   // Your data
  const data = [
    { id: "001", name: "John Doe", email: "john@email.com", user: "John Doe", status: "Active" },
    { id: "002", name: "Jane Smith", email: "jane@email.com", user: "Jane Smith", status: "Pending" },
    { id: "003", name: "Bob Wilson", email: "bob@email.com", user: "Bob Wilson", status: "Approved" },
    { id: "004", name: "Jikki Brown", email: "alice@email.com", user: "Alice Brown", status: "Rejected" },
    { id: "005", name: "jackson Day", email: "charlie@email.com", user: "Charlie Day", status: "Active" },
    { id: "005", name: "Bari Day", email: "charlie@email.com", user: "Charlie Day", status: "Active" },
    { id: "006", name: "ketti Doe", email: "john@email.com", user: "John Doe", status: "Active" },
    { id: "007", name: "Sam Smith", email: "jane@email.com", user: "Jane Smith", status: "Pending" },
    { id: "008", name: "Alex Wilson", email: "bob@email.com", user: "Bob Wilson", status: "Approved" },
    { id: "009", name: "Rice Brown", email: "alice@email.com", user: "Alice Brown", status: "Rejected" },
    { id: "010", name: "Bob Day", email: "charlie@email.com", user: "Charlie Day", status: "Active" },
    { id: "011", name: "Rahul Day", email: "charlie@email.com", user: "Charlie Day", status: "Active" },
    { id: "012", name: "Geetha Doe", email: "john@email.com", user: "John Doe", status: "Active" },
    { id: "013", name: "Ruk Smith", email: "jane@email.com", user: "Jane Smith", status: "Pending" },
    { id: "014", name: "Bell Wilson", email: "bob@email.com", user: "Bob Wilson", status: "Approved" },
    { id: "015", name: "Alice Brown", email: "alice@email.com", user: "Alice Brown", status: "Rejected" },
    { id: "016", name: "Gadu Day", email: "charlie@email.com", user: "Charlie Day", status: "Active" },
    { id: "017", name: "Anthony Day", email: "charlie@email.com", user: "Charlie Day", status: "Active" },

        
  ]
  // Define your tabs
  const tabs = [
    { label: "All", value: "all", count: data.length },
    { label: "Active", value: "Active", count: data.filter(d => d.status === "Active").length },
    { label: "Pending", value: "Pending", count: data.filter(d => d.status === "Pending").length },
    { label: "Approved", value: "Approved", count: data.filter(d => d.status === "Approved").length },
    { label: "Rejected", value: "Rejected", count: data.filter(d => d.status === "Rejected").length },
  ]



return (

  
  <>
    {/* MAIN PAGE */}
    <div className="page-container">

       <Breadcrumb items={["Dashboard", "Document Requests"]} />

       <PageHeader
          title="Document Requests"
          actions={
         
            <button className="btn btn--primary"onClick={() => setOpenSlider(true)}>
            <span className="btn__icon">
              <svg  width="24" height="24" fill="currentColor" viewBox="0 0 24 24">
              <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.7" d="M5 12h14m-7 7V5"/>
            </svg>



            </span>
            <span>New Request</span>
          </button>
          }
        />
      <Tabsunderline  tabs={dashboardTabs} />

     {/* TABLE WITH TABS INSIDE TOOLBAR */}
       <Table 
          columns={columns}
          data={data}
          isLoading={isFetching} 
          enableDragDrop={false}
          enableColumnResize={true} 
          showCheckbox={true} 
          onCreate={() => setOpenSlider(true)}
          showToolbar={true}
          stickyHeader={true} 
          pagination={true}
          pageSize={10}
          expandable={true}
          expandContent={(row) => (
            <div>
              <h4>Details for {row.name}</h4>
              <p>Email: {row.email}</p>
              <p>Phone: +1 234 567 8900</p>
            </div>
          )}
          tabs={tabs}
          actions={(row) => (
            <div className="action-buttons">
              <svg width="24" height="24"  fill="none" viewBox="0 0 24 24">
                <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1" d="M10.779 17.779 4.36 19.918 6.5 13.5m4.279 4.279 8.364-8.643a3.027 3.027 0 0 0-2.14-5.165 3.03 3.03 0 0 0-2.14.886L6.5 13.5m4.279 4.279L6.499 13.5m2.14 2.14 6.213-6.504M12.75 7.04 17 11.28"/>
              </svg>

             <svg   width="24" height="24" fill="none" viewBox="0 0 24 24">
              <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.3" d="M5 7h14m-9 3v8m4-8v8M10 3h4a1 1 0 0 1 1 1v3H9V4a1 1 0 0 1 1-1ZM6 7h12v13a1 1 0 0 1-1 1H7a1 1 0 0 1-1-1V7Z"/>
            </svg>

            </div>
          )}
          filterKey="status"
          searchPlaceholder="Search requests..."
          exportFilename="document-requests"
      
          
          // NEW: Delete functionality
          onDelete={(ids, reason) => {
            console.log("Deleting IDs:", ids)
            console.log("Reason:", reason)
            
            // Call your API here
            // await deleteApi(ids, reason)
            
            // Show success message
            alert(`${ids.length} item(s) deleted. Reason: ${reason}`)
          }}
          deleteIdKey="id"  // Tell it which field is the ID
        />


      

    </div>

    {/* 🔥 PAGE SLIDER (ADD HERE) */}
    <PageSlider
      isOpen={openSlider}
      onClose={() => setOpenSlider(false)}
    >
      <PageSliderHeader
        title="New Request"
        onClose={() => setOpenSlider(false)}
        actions={
          <>
            <button className="btn btn--secondary" onClick={handleSave}>
            <span className="btn__icon">
             <svg  width="24" height="24" viewBox="0 0 24 24">
            <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18 17.94 6M18 18 6.06 6"/>
          </svg>

            </span>
            <span>Cancel</span>
          </button>
  

            <button className="btn btn--primary" onClick={handleSave}>
            <span className="btn__icon">
              <svg width="24" height="24"  viewBox="0 0 24 24">
              <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 12H5m14 0-4 4m4-4-4-4"/>
            </svg>


            </span>
            <span>Save</span>
          </button>
          </>
        }
      />

      <PageSliderBody>
<div> 
        <div className="col1" >sdsdddsd</div>
        <div  className="col1">
            <FormRow>
                    <FormField label="Borrower Name" error={errors.borrower} required>
                      <Input
                        value={borrower}
                        onChange={(val) => {
                          setBorrower(val)
                          setErrors((prev: any) => ({
                            ...prev,
                            borrower: ""
                          }))
                        }}
                      />
                    </FormField>

                    <FormField label="Borrower Name" error={errors.borrower} required>
                      <Input
                        value={borrower}
                        onChange={(val) => {
                          setBorrower(val)
                          setErrors((prev: any) => ({
                            ...prev,
                            borrower: ""
                          }))
                        }}
                      />
                    </FormField>
              </FormRow>

            <FormRow>
            <FormField label="Date" error={errors.date} required>
              <Input
                type="date"
                value={date}
                onChange={(val) => {
                  setDate(val)
                  setErrors((prev: any) => ({
                    ...prev,
                    date: ""
                  }))
                }}
              />
            </FormField>
            </FormRow>
             <FormRow>
            <FormField label="Proposal No" error={errors.proposal} required>
              <ComboBox
                value={proposal}
                onChange={(val) => {
                  setProposal(val)
                  setErrors((prev: any) => ({
                    ...prev,
                    proposal: ""
                  }))
                }}
                options={[
              { label: "PROP-001237888784", value: "1" },
              { label: "PROP-009856565676", value: "2" },
              { label: "PROP-004356565621", value: "3" }
            ]}
              />
            </FormField>
            </FormRow> 
            <FormRow>
          <FormField label="Date" error={errors.date} required>
            <Input
              type="date"
              value={date}
              onChange={(val) => {
                setDate(val)
                setErrors((prev: any) => ({
                  ...prev,
                  date: ""
                }))
              }}
            />
          </FormField>
          </FormRow>    


        <FormRow>
        
          <FormField label="Remarks">
            <Textarea
              value={remark}
              onChange={(val) => setRemark(val)}
            />
          </FormField>

        </FormRow>

        
        <FormRow>
        <FormField label="Country" error={errors.country} required>
          <Select
            value={country}
            onChange={(e) => {
              setCountry(e.target.value)
              setErrors((prev: any) => ({
                ...prev,
                country: ""
              }))
            }}
            options={[
              { label: "India", value: "IN" },
              { label: "USA", value: "US" }
            ]}
          />
        </FormField>
        </FormRow>



        </div>
  
                       
</div>












</PageSliderBody>

    </PageSlider>
  </>
)

}