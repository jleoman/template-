import BreadcrumbHeader from "../../components/breadcrumb/Breadcrumb"

export default function Tracking() {

  return (

    <div className="page-container">

      <BreadcrumbHeader
        title="Tracking"
        breadcrumb={["Dashboard", "tracking"]}
      />

      <div>Tracking Page</div>

    </div>

  )

}