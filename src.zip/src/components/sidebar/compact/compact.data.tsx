import type { CompactMenuItem } from "./compact.types"
import DashboardIcon from "@/assets/icons/default.svg?react"


export const compactMenu: CompactMenuItem[] = [
  {
    id: "dashboard",
    label: "Dashboard",
    icon: <DashboardIcon width={18} height={18} />,
    path: "/dashboard"
  },

{
   id: "requests",
    label: "Document Requests",
    path: "/requests",
    icon: <DashboardIcon width={18} height={18} />
  },

  {
    id: "approvals",
    label: "Approvals",
    path: "/approvals",
     icon: <DashboardIcon width={18} height={18} />
  },

  {
    id: "repository",
    label: "Repository",
    path: "/repository",
    icon: <DashboardIcon width={18} height={18} />
  },

  {
    id: "tracking",
    label: "Tracking",
    path: "/tracking",
     icon: <DashboardIcon width={18} height={18} />
  },


  
  /*{
    id: "pending",
    label: "Pending Approval",
    icon: <SettingsIcon/>,
    children: [
      { id: "lvl1", label: "Level 1", icon: <SettingsIcon/>,
         children: [
      { id: "lvl1", label: "Level 2", icon: <SettingsIcon/>,
         children: [
      { id: "lvl31", label: "Level 3", icon: <SettingsIcon/> },
      { id: "lvl32", label: "Level 3", icon: <SettingsIcon/> },
      { id: "lvl33", label: "Level 3", icon: <SettingsIcon/> },
      { id: "lvl34", label: "Level 3", icon: <SettingsIcon/> },
      { id: "lvl35", label: "Level 3", icon: <SettingsIcon/> },
      { id: "lvl36", label: "Level 3", icon: <SettingsIcon/> },
      { id: "lvl37", label: "Level 3", icon: <SettingsIcon/> }
    ]
       },
      { id: "lvl21", label: "Level 2", icon: <SettingsIcon/> },
      { id: "lvl22", label: "Level 2", icon: <SettingsIcon/> },
      { id: "lvl23", label: "Level 2", icon: <SettingsIcon/> },
      { id: "lvl24", label: "Level 2", icon: <SettingsIcon/> },
      { id: "lvl25", label: "Level 2", icon: <SettingsIcon/> },
      { id: "lvl26", label: "Level 2", icon: <SettingsIcon/> },
      { id: "lvl27", label: "Level 2", icon: <SettingsIcon/> }
    ]
       },
      { id: "lvl2", label: "Level 1", icon: <SettingsIcon/>},
      { id: "lvl3", label: "Level 1", icon: <SettingsIcon/>},
      { id: "lvl4", label: "Level 1", icon: <SettingsIcon/>},
      { id: "lvl5", label: "Level 1", icon: <SettingsIcon/>},
      { id: "lvl6", label: "Level 1", icon: <SettingsIcon/>},
      { id: "lvl7", label: "Level 1", icon: <SettingsIcon/>},
      { id: "lvl8", label: "Level 1", icon: <SettingsIcon/>},
      { id: "lvl9", label: "Level 1", icon: <SettingsIcon/>},
      { id: "lvl10", label: "Level 1", icon: <SettingsIcon/>},
   
    ]
  },
  {
    id: "requests",
    label: "My Requests",
    icon: <PoliciesIcon width={18} height={18} />
  },
  {
    id: "approvals",
    label: "My Approvals",
    icon: <DashboardIcon width={18} height={18} />
  }*/

]