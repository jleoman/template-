

import { useState, useEffect, useRef } from "react"
import LogoFull from "@/assets/icons/logo-full.svg?react"
import LogoCompact from "@/assets/icons/logo-compact-2.svg?react"
import ToggleIcon from "@/assets/icons/toggle.svg?react"
import ChevronDownIcon from "@/assets/icons/chevron.svg?react"
import { compactMenu } from "./compact.data"
import "./_compact.scss"
import { useNavigate, useLocation } from "react-router-dom"

const SidebarCompact = () => {
  const navigate = useNavigate()
  const location = useLocation()
  const [collapsed, setCollapsed] = useState(true)
  const [openMenu, setOpenMenu] = useState<string | null>(null)
  const [compactPopout, setCompactPopout] = useState<string | null>(null)
  const [compactOpenMap, setCompactOpenMap] = useState<Record<string, boolean>>({})
  const [tooltipY, setTooltipY] = useState(0)
  const [popoutY, setPopoutY] = useState(0)
  const [userOpen, setUserOpen] = useState(false)
  const [popoutMaxHeight, setPopoutMaxHeight] = useState<number | null>(null)
  const [isClosing, setIsClosing] = useState(false)
  const [activeLevel, setActiveLevel] = useState<string | null>(null)


  const popoutRef = useRef<HTMLDivElement | null>(null)
  useEffect(() => {
  const handleClickOutside = (event: MouseEvent) => {
    if (
      popoutRef.current &&
      !popoutRef.current.contains(event.target as Node)
    ) {
      setIsClosing(true)

        setTimeout(() => {
        setCompactPopout(null)
        setIsClosing(false)
        }, 180) // match CSS duration
    }
  }

  if (compactPopout) {
    document.addEventListener("mousedown", handleClickOutside)
  }

  return () => {
    document.removeEventListener("mousedown", handleClickOutside)
  }
}, [compactPopout])

  /* ================= TREE TOGGLE (SMART) ================= */

  const toggleCompact = (id: string) => {
    setCompactOpenMap(prev => {
      const updated = { ...prev }

      if (updated[id]) {
        // Close this node + its descendants only
        Object.keys(updated).forEach(key => {
          if (key === id || key.startsWith(id + "-")) {
            delete updated[key]
          }
        })
      } else {
        updated[id] = true
      }

      return updated
    })
  }

  /* ================= COMPACT TREE RENDER ================= */

  const renderCompactTree = (
    items: any[],
    level = 1,
    parentPath = ""
  ) => {
    return (
      <div className={`compact-level level-${level}`}>
        {items.map((item) => {
          const uniqueKey = parentPath
            ? `${parentPath}-${item.id}`
            : item.id

          return (
            <div key={uniqueKey} className="compact-node">

              <div
             className={`compact-item ${
                  activeLevel === uniqueKey ||
                  (item.path && location.pathname.startsWith(item.path))
                    ? "active"
                    : ""
                }`}
              onClick={() => {
                  if (item.children) {
                    toggleCompact(uniqueKey)
                    setActiveLevel(uniqueKey)
                  } else {
                    setActiveLevel(uniqueKey)

                    if (item.path) {
                      navigate(item.path)
                    }
                  }
}}
                >
                {/* ICON */}
                <div className="compact-icon">
                  {item.icon}
                </div>

                <span className="compact-label">
                  {item.label}
                </span>

                {item.children && (
                  <ChevronDownIcon
                    width={14}
                    height={14}
                    className={`arrow ${
                      compactOpenMap[uniqueKey] ? "open" : ""
                    }`}
                  />
                )}
              </div>

              {item.children &&
                compactOpenMap[uniqueKey] &&
                renderCompactTree(
                  item.children,
                  level + 1,
                  uniqueKey
                )}
            </div>
          )
        })}
      </div>
    )
  }

  return (
    <aside className={`sidebar-compact ${collapsed ? "collapsed" : ""}`}>

      {/* ================= LOGO ================= */}
      <div className="sidebar-compact__logo">
        {!collapsed ? (
          <>
            <LogoFull />
            <button
              className="sidebar-compact__toggle"
              onClick={() => setCollapsed(true)}
            >
              <ToggleIcon width={18} height={18} />
            </button>
          </>
        ) : (
          <div
            className="sidebar-compact__logo-collapsed"
            onClick={() => setCollapsed(false)}
          >
            <LogoCompact width={34} height={34} />
            <span className="hover-toggle">
              <ToggleIcon width={18} height={18} />
            </span>
          </div>
        )}
      </div>

      {/* ================= MENU ================= */}
      <div className="sidebar-compact__menu">
        {compactMenu.map((item) => {
          const isPopoutOpen =
            collapsed && compactPopout === item.id

          return (
            <div
                key={item.id}
                className={`menu-item ${
                  (item.path && location.pathname.startsWith(item.path)) ||
                  (collapsed && compactPopout === item.id)
                    ? "active"
                    : ""
                }`}
                >

              {/* MAIN ICON */}
              <div
                className="menu-link"
                onMouseEnter={(e) => {
                  if (collapsed && !compactPopout) {
                    const rect =
                      e.currentTarget.getBoundingClientRect()
                    setTooltipY(rect.top + rect.height / 2)
                  }
                }}
                onClick={(e) => {

                              // ✅ HANDLE LEAF NODE (TOP LEVEL)
                              if (!item.children && item.path) {
                                navigate(item.path)
                                return
                              }

                              // EXISTING LOGIC (UNCHANGED)
                              if (collapsed && item.children) {

                                const rect = e.currentTarget.getBoundingClientRect()
                                const viewportHeight = window.innerHeight
                                const margin = 20
                                let top = rect.top
                                const availableHeight = viewportHeight - top - margin

                                setPopoutY(top)
                                setPopoutMaxHeight(availableHeight)

                                setCompactOpenMap({})
                                setCompactPopout(
                                  compactPopout === item.id ? null : item.id
                                )

                              } else if (item.children) {

                                setOpenMenu(
                                  openMenu === item.id ? null : item.id
                                )

                              }

                            }}
              >
                <div className="icon">
                  {item.icon}
                </div>

                {!collapsed && (
                  <>
                    <span className="label">
                      {item.label}
                    </span>

                    {item.children && (
                      <ChevronDownIcon
                        width={14}
                        height={14}
                        className={`arrow ${
                          openMenu === item.id
                            ? "open"
                            : ""
                        }`}
                      />
                    )}
                  </>
                )}
              </div>

              {/* EXPANDED MODE */}
              {item.children &&
                openMenu === item.id &&
                !collapsed && (
                  <div
                    className={`submenu-expanded ${
                        openMenu === item.id ? "open" : ""
                    }`}
                    >
                    {renderCompactTree(item.children)}
                  </div>
                )}

              {/* COMPACT MODE POPOUT */}
              {isPopoutOpen && item.children && (
  <div ref={popoutRef}
    className={`compact-popout ${isClosing ? "closing" : "opening"}`}
    style={{
      top: popoutY,
      left: 80,
      maxHeight: popoutMaxHeight ?? undefined,
      overflowY: "auto"
    }}
  >
                  {renderCompactTree(item.children)}
                </div>
              )}

              {/* TOOLTIP */}
              {collapsed && !compactPopout && (
                <div
                  className="tooltip"
                  style={{
                    top: tooltipY,
                    left: 60,
                    transform: "translateY(-50%)"
                  }}
                >
                  {item.label}
                </div>
              )}
            </div>
          )
        })}
      </div>

      {/* ================= USER ================= */}
      <div className="sidebar-compact__user">
        <div
          className="avatar"
          onClick={() => setUserOpen(!userOpen)}
        >
          JL
        </div>

        {!collapsed && (
          <div className="user-info">
            <div className="user-name">
              Jackson Leoman
            </div>
            <div className="user-email">
              AAMOCI20190
            </div>
          </div>
        )}

        {collapsed && userOpen && (
          <div className="user-popout">
            <div className="user-name">
              Jackson Leoman
            </div>
            <button className="logout-btn">
              Logout
            </button>
          </div>
        )}
      </div>
    </aside>
  )
}

export default SidebarCompact