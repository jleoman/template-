export interface CompactMenuItem {
  id: string
  label: string
  icon: React.ReactNode
  path?: string
  children?: CompactMenuItem[]
}