import { useState, useRef, useEffect } from "react"
import Logo from "@/assets/icons/logo-compact.svg?react"
import { NavLink } from "react-router-dom"
import { classicMenu } from "./classic.data"
import "./_classic.scss"

export default function ClassicSidebar() {
  const [open, setOpen] = useState(false)
  const dropdownRef = useRef<HTMLDivElement>(null)

  // Close on outside click
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (
        dropdownRef.current &&
        !dropdownRef.current.contains(event.target as Node)
      ) {
        setOpen(false)
      }
    }

    document.addEventListener("mousedown", handleClickOutside)
    return () => document.removeEventListener("mousedown", handleClickOutside)
  }, [])

  return (
    <aside className="sidebar-classic">

      {/* Logo */}
      <div className="sidebar-logo">
        <Logo width={40} height={40} />
      </div>

      {/* Menu */}
      <div className="sidebar-classic__inner">
        {classicMenu.map((item) => (
          <NavLink
            key={item.id}
            to={item.path}
            className={({ isActive }) =>
              `classic-item ${isActive ? "active" : ""}`
            }
          >
            <div className="classic-item__icon">
              {item.icon}
            </div>
            <span className="classic-item__label">
              {item.label}
            </span>
          </NavLink>
        ))}
      </div>

      {/* User Section */}
      <div className="sidebar-user-wrapper" ref={dropdownRef}>
        <div
          className="sidebar-user"
          onClick={() => setOpen(!open)}
        >
          JL
        </div>

        {open && (
          <div
            className={`user-dropdown ${open ? "open" : ""}`}
            >
            <div className="user-name">Jagan Leo</div>
            <button className="logout-btn">Logout</button>
            </div>
        )}
      </div>

    </aside>
  )
}