import type { ClassicMenuItem } from "./classic.types"

import PortfolioIcon from "@/assets/icons/default.svg?react"
import MarketIcon from "@/assets/icons/default.svg?react"
import TradingIcon from "@/assets/icons/default.svg?react"
import StocksIcon from "@/assets/icons/default.svg?react"
import ScannerIcon from "@/assets/icons/default.svg?react"
import AnalyticsIcon from "@/assets/icons/default.svg?react"
import SettingsIcon from "@/assets/icons/default.svg?react"
import InviteIcon from "@/assets/icons/default.svg?react"

export const classicMenu: ClassicMenuItem[] = [

  { id: "portfolio", label: "Portfolio", path: "/portfolio", icon: <PortfolioIcon width={22} height={22} /> },
  { id: "market", label: "Market", path: "/market", icon: <MarketIcon width={22} height={22} /> },
  { id: "trading", label: "Trading", path: "/trading", icon: <TradingIcon width={22} height={22} /> },
  { id: "stocks", label: "Stocks", path: "/stocks", icon: <StocksIcon width={22} height={22} /> },
  { id: "scanner", label: "Scanner", path: "/scanner", icon: <ScannerIcon width={22} height={22} /> },
  { id: "analytics", label: "Analytics", path: "/analytics", icon: <AnalyticsIcon width={22} height={22} /> },
  { id: "settings", label: "Settings", path: "/settings", icon: <SettingsIcon width={22} height={22} /> },
  { id: "invite", label: "Invite", path: "/invite", icon: <InviteIcon width={22} height={22} /> },
]