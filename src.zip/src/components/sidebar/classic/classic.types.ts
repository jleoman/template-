export type ClassicMenuItem = {
  id: string
  label: string
  path: string
  icon: React.ReactNode
}