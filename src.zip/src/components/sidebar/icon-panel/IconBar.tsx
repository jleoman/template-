import { useState, useRef, useEffect } from 'react'
import type { SidebarItem } from './sidebar.types'

interface Props {
  items: SidebarItem[]
  activeItem: SidebarItem | null
  onSelect: (item: SidebarItem) => void
}

function IconBar({ items, activeItem, onSelect }: Props) {
  const [userMenuOpen, setUserMenuOpen] = useState(false)

  // ✅ DEFINE REF
  const userRef = useRef<HTMLDivElement>(null)

  // ✅ OUTSIDE CLICK LOGIC
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (
        userRef.current &&
        !userRef.current.contains(event.target as Node)
      ) {
        setUserMenuOpen(false)
      }
    }

    document.addEventListener('mousedown', handleClickOutside)

    return () => {
      document.removeEventListener('mousedown', handleClickOutside)
    }
  }, [])

  return (
    <div className="iconbar">
      <div className="iconbar__logo">G</div>

      {items.map(item => (
        <div
          key={item.id}
          className="iconbar__item-wrapper"
          onClick={() => onSelect(item)}
        >
          <div
            className={`iconbar__item ${
              activeItem?.id === item.id ? 'iconbar__item--active' : ''
            }`}
          >
            {item.icon}
          </div>
          <span className="tooltip">{item.label}</span>
        </div>
      ))}

      <div className="iconbar__spacer" />

      {/* USER SECTION */}
      <div ref={userRef} className="iconbar__user-wrapper">
        <div
          className="iconbar__user"
          onClick={() => setUserMenuOpen(prev => !prev)}
        >
          JL
        </div>

        {userMenuOpen && (
          <div className="iconbar__user-menu">
            <div className="iconbar__user-item">Profile</div>
            <div className="iconbar__user-item">Logout</div>
          </div>
        )}
      </div>
    </div>
  )
}

export default IconBar