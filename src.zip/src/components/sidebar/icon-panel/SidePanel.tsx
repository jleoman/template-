import { useState } from 'react'
import type { SidebarItem } from './sidebar.types'
import ArrowIcon from '@/assets/icons/chevron.svg?react'




interface Props {
  item: SidebarItem | null
}

function SidePanel({ item }: Props) {
  if (!item || !item.children) return null

  return (
    <>
      <div className="sidepanel__title">{item.label}</div>

      <div className="sidepanel__content">
        <RecursiveList items={item.children} level={0} />
      </div>
      <div></div>
    </>
  )
}

/* 🔥 Controls ONE LEVEL at a time */
function RecursiveList({
  items,
  level,
}: {
  items: SidebarItem[]
  level: number
}) {
  const [openId, setOpenId] = useState<string | null>(null)

  return (
    <>
      {items.map(item => {
        const hasChildren =
          Array.isArray(item.children) &&
          item.children.length > 0

        const isOpen = openId === item.id

        return (
          <div
            key={item.id}
            className={`sidepanel__group level-${level}`}
          >
            <div
              className="sidepanel__item"
              onClick={() => {
                if (!hasChildren) return

                // Toggle + auto-close siblings
                setOpenId(prev =>
                  prev === item.id ? null : item.id
                )
              }}
            >
              <div className="sidepanel__item-left">
                {item.icon ? (
                  <span className="sidepanel__icon">
                    {item.icon}
                  </span>
                ) : (
                  <span className="sidepanel__dot" />
                )}

                <span>{item.label}</span>
              </div>

              {hasChildren && (
               <span className={`arrow ${isOpen ? 'open' : ''}`}>
                <ArrowIcon />
              </span>
              )}
            </div>

            {/* 🔥 Always render container for animation */}
            {hasChildren && (
              <div
                className={`sidepanel__children ${
                  isOpen ? 'sidepanel__children--open' : ''
                }`}
              >
                <RecursiveList
                  items={item.children!}
                  level={level + 1}
                />
              </div>
            )}
          </div>
        )
      })}
    </>
  )
}

export default SidePanel