import type { SidebarItem } from './sidebar.types'
// 👇 ADD YOUR ICON IMPORTS HERE
import DashboardIcon from '@/assets/icons/default.svg?react'
import SettingsIcon from '@/assets/icons/default.svg?react'
import PoliciesIcon from '@/assets/icons/default.svg?react'




export const sidebarItems: SidebarItem[] = [
  { id: 'dashboard', label: 'Dashboard', icon: <DashboardIcon /> },
  { id: 'settings', label: 'Settings', icon: <SettingsIcon /> },

  {
    id: 'policies',
    label: 'Policies',
    icon: <PoliciesIcon />,
    children: [
      {
        id: 'group1',
        label: 'Heading',
        icon: <PoliciesIcon />,
        children: [
          { id: 'link1', label: 'Link1' },
          { id: 'link2', label: 'Link2' }
        ]
      },
      // 2️⃣ New group WITH children
      {
        id: 'group2',
        label: 'Sub Menu',
        icon: <PoliciesIcon />,
        children: [
          { id: 'link3', label: 'Link3', 
            children: [
          { id: 'link3', label: 'Link3' },
          { id: 'link4', label: 'Link4' }
        ]


          },
          { id: 'link4', label: 'Link4' }
        ]
      },
      {
        id: 'reports',
        label: 'Reports',
        icon: <PoliciesIcon />
      }
      
    ]
  }
]