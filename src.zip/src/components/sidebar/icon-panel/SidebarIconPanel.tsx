import { useState } from 'react'
import { sidebarItems } from './sidebar.data'
import type { SidebarItem } from './sidebar.types'
import IconBar from './IconBar'
import SidePanel from './SidePanel'
import './_icon-panel.scss'

function SidebarIconPanel() {
  const [activeItem, setActiveItem] = useState<SidebarItem | null>(null)

  const handleSelect = (item: SidebarItem) => {
    const hasChildren = !!item.children

    if (!hasChildren) {
      setActiveItem(null)
      return
    }

    if (activeItem?.id === item.id) {
      setActiveItem(null)
      return
    }

    setActiveItem(item)
  }

  const isOpen = !!activeItem?.children

  return (
    <aside className="sidebar-icon-panel">
      <div className="sidebar-layout">
        <IconBar
          items={sidebarItems}
          activeItem={activeItem}
          onSelect={handleSelect}
        />

        {/* 👇 DO NOT REMOVE THIS DIV */}
        <div className={`sidepanel ${isOpen ? 'sidepanel--open' : ''}`}>
          {activeItem && <SidePanel item={activeItem} />}
        </div>
      </div>
    </aside>
  )
}

export default SidebarIconPanel