import type { ReactNode } from 'react'

export interface SidebarItem {
  id: string
  label: string
  icon?: ReactNode   // 👈 change this
  children?: SidebarItem[]
}