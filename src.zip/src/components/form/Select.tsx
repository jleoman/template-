import React from "react"

interface Option {
  label: string
  value: string
}

interface Props {
  options: Option[]
  value: string
  onChange: (e: React.ChangeEvent<HTMLSelectElement>) => void
  disabled?: boolean
}

const Select = ({ options, value, onChange, disabled }: Props) => {
  return (
      <select
        value={value}
        onChange={onChange}
        className="form-input"
      >
      {options.map((option) => (
        <option key={option.value} value={option.value}>
          {option.label}
        </option>
      ))}
    </select>
  )
}

export default Select