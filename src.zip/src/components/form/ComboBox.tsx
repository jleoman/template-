import { useState, useRef, useEffect } from "react"
import type { Option } from "../../components/form/types"



interface Props {
  options: Option[]
  value?: Option | null
  onChange?: (value: Option | null) => void
  placeholder?: string

}

export default function ComboBox({
  options,
  value,
  onChange,

}: Props) {
    
  const [query, setQuery] = useState(value?.label || "")
  const [open, setOpen] = useState(false)
  const [activeIndex, setActiveIndex] = useState(-1)
  const wrapperRef = useRef<HTMLDivElement>(null)
useEffect(() => {

}, [query])


  useEffect(() => {
  setQuery(value?.label || "")
}, [value])


  // 🔍 Filter options
  const filtered = options.filter(opt =>
    opt.label.toLowerCase().includes(query.toLowerCase())
  )

  // 📌 Close on outside click

  
  useEffect(() => {
    const handleClickOutside = (e: any) => {
      if (!wrapperRef.current?.contains(e.target)) {
        setOpen(false)
      }
    }

    document.addEventListener("mousedown", handleClickOutside)
    return () =>
      document.removeEventListener("mousedown", handleClickOutside)
  }, [])

  // ✅ Select option
  const handleSelect = (opt: Option) => {
    setQuery(opt.label)
    setOpen(false)
    onChange?.(opt)
  }

  // ❌ Clear selection
  const handleClear = () => {
    setQuery("")
    onChange?.(null)
  }


  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
  if (!open) return

  if (e.key === "ArrowDown") {
    e.preventDefault()
    setActiveIndex((prev) =>
      prev < filtered.length - 1 ? prev + 1 : 0
    )
  }

  if (e.key === "ArrowUp") {
    e.preventDefault()
    setActiveIndex((prev) =>
      prev > 0 ? prev - 1 : filtered.length - 1
    )
  }

  if (e.key === "Enter") {
    e.preventDefault()
    if (filtered[activeIndex]) {
      handleSelect(filtered[activeIndex])
    }
  }

  if (e.key === "Escape") {
    setOpen(false)
  }
}
return (
  <div ref={wrapperRef}>
    <div className="input-wrapper has-suffix">

      <input onKeyDown={handleKeyDown}
        className={`form-input ${query ? "has-value" : ""}`}
        value={query}
        placeholder=" "
        onFocus={() => setOpen(true)}
        onChange={(e) => {
          setQuery(e.target.value)
          setOpen(true)
          setActiveIndex(-1)
        }}
      />

      <span className="input-suffix">
        {query ? (
          <button
            type="button"
            className="clear-btn"
            onClick={handleClear}
          >
            ✕
          </button>
        ) : (
          <button
                type="button"
                className="dropdown-btn"
                onClick={() => setOpen((prev) => !prev)}
                >
                ▾
                </button>
        )}
      </span>

      {/* ✅ MOVE LABEL HERE */}
     

    </div>

    {open && (
      <div className="combo-dropdown">
        {filtered.map((opt, index) => (
          <div
                key={opt.value}
                className={`combo-item ${index === activeIndex ? "active" : ""}`}
                onClick={() => handleSelect(opt)}
            >
                {opt.label}
            </div>
        ))}
      </div>
    )}
  </div>
)
}