import { useState, useRef, useEffect } from "react"
import searchIcon from "../../assets/icons/default.svg" 



interface Option {
  label: string
  value: string
}

interface Props {
  options: Option[]
  placeholder?: string
  onSelect?: (value: Option) => void
}

export default function SearchSelect({
    
  options,
  placeholder = "Search proposal...",
  onSelect
}: Props) {
  const [query, setQuery] = useState("")
  const [open, setOpen] = useState(false)
  const wrapperRef = useRef<HTMLDivElement>(null)

  // 🔍 filter logic
  const filtered = options.filter(opt =>
    opt.label.toLowerCase().includes(query.toLowerCase())
  )

  // ❌ close on outside click
  useEffect(() => {
    const handleClickOutside = (e: any) => {
      if (!wrapperRef.current?.contains(e.target)) {
        setOpen(false)
      }
    }
    document.addEventListener("mousedown", handleClickOutside)
    return () => document.removeEventListener("mousedown", handleClickOutside)
  }, [])

  const handleSelect = (opt: Option) => {
    setQuery(opt.label) // ✅ stays in input
    setOpen(false)
    onSelect?.(opt)
  }

  const clear = () => {
    setQuery("")
    setOpen(false)
  }

  return (
    <div
  className={`form-control ${query ? "has-value" : ""}`}
  ref={wrapperRef}
>
  <div className="input-wrapper has-suffix">

    <input
      className="form-input"
      value={query}
      placeholder=" "
      onFocus={() => setOpen(true)}
      onChange={(e) => {
        setQuery(e.target.value)
        setOpen(true)
      }}
    />

    {/* RIGHT ICON */}
    <span className="input-suffix">
      {query ? (
        <span className="clear-btn" onClick={clear}>✕</span>
      ) : (
        <img src={searchIcon} alt="search" />
      )}
    </span>

  </div>

  {/* DROPDOWN */}
  {open && filtered.length > 0 && (
    <div className="search-dropdown">
      {filtered.map(opt => (
        <div
          key={opt.value}
          className="search-item"
          onClick={() => handleSelect(opt)}
        >
          {opt.label}
        </div>
      ))}
    </div>
  )}
</div>
  )
}
