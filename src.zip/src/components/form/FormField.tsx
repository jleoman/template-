import { useState, useEffect } from "react"
import React from "react"

interface Props {
  label?: string
  children: React.ReactElement<any>
  error?: string
  required?: boolean
}

export default function FormField({
  label,
  children,
  error,
  required,
}: Props) {
  const [focused, setFocused] = useState(false)
  const [hasValue, setHasValue] = useState(false)

  useEffect(() => {
    const value = children.props.value
    setHasValue(!!value)
  }, [children.props.value])

  const child = React.cloneElement(children, {
    onFocus: () => setFocused(true),
    onBlur: () => setFocused(false),
  })

  return (
    <div className={`form-control ${focused ? "focused" : ""} ${hasValue ? "has-value" : ""} ${error ? "error" : ""}`}>
      <div className="input-wrapper">
        {child}
        {label && <label className="form-label">{label} {required && "*"}</label>}
      </div>
      {error && <span className="form-error">{error}</span>}
    </div>
  )
}