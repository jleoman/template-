interface Props {
  value?: string
  onChange?: (value: string) => void
}

export default function Textarea({
  value,
  onChange,
}: Props) {
  return (
    <textarea
      className="form-input"
      value={value}
      onChange={(e) => onChange?.(e.target.value)}
    />
  )
}