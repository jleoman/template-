import React from "react"

interface Props extends React.InputHTMLAttributes<HTMLInputElement> {
  startIcon?: React.ReactNode
  endIcon?: React.ReactNode
}

const InputField = ({
  startIcon,
  endIcon,
  className = "",
  value,
  ...props
}: Props) => {
  return (
    <div className={`input-wrapper ${props.disabled ? "is-disabled" : ""}`}>

      {startIcon && <div className="input-prefix">{startIcon}</div>}

      <input
        {...props}
        value={value}
        className={`form-input ${value ? "has-value" : ""} ${className}`}
        placeholder=" "
      />

      {endIcon && <div className="input-suffix">{endIcon}</div>}
    </div>
  )
}

export default InputField