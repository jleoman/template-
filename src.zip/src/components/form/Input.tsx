interface Props {
  value?: string
  onChange?: (value: string) => void
  type?: string
}

export default function Input({
  value,
  onChange,
  type = "text",
}: Props) {
  return (
    <input
      type={type}
      className="form-input"
      value={value}
      onChange={(e) => onChange?.(e.target.value)}
    />
  )
}