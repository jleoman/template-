// components/page-header/PageHeader.tsx

interface Props {
  title: string
  actions?: React.ReactNode
}

export default function PageHeader({ title, actions }: Props) {
  return (
    <div className="page-header">
      <h1 className="page-title">{title}</h1>
      <div className="page-actions">
        {actions}
      </div>
    </div>
  )
}