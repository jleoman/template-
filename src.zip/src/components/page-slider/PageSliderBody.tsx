


const PageSliderBody = ({ children }: { children: React.ReactNode }) => {
  return (
    <div className="page-slider__body">
      {children}
    </div>
  )
}

export default PageSliderBody