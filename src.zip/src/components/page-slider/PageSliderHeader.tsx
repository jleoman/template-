interface Props {
  title: string
  onClose: () => void
  actions?: React.ReactNode
}

const PageSliderHeader = ({ title, onClose, actions }: Props) => {
  return (
    <div className="page-slider__header">
       <button className="btn-close" onClick={onClose}>✕</button>
      <div className="title">{title}</div>

      <div className="actions">
        {actions}
       
      </div>

    </div>
  )
}

export default PageSliderHeader