import "./_page-slider.scss"


interface Props {
  isOpen: boolean
  onClose: () => void
  children: React.ReactNode
}

const PageSlider = ({ isOpen, onClose, children }: Props) => {
  return (
    <div className={`page-slider ${isOpen ? "open" : ""}`}>

      {/* Overlay */}
      <div className="page-slider__overlay" onClick={onClose} />

      {/* Panel */}
      <div className="page-slider__panel">
        {children}
      </div>

    </div>
  )
}

export default PageSlider