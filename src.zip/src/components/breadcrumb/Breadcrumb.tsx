

interface Props {
  items: string[]
}

export default function Breadcrumb({ items }: Props) {
  return (
    <div className="breadcrumb">
      {items.map((item, index) => (
        <span key={index} className="breadcrumb-item">
          {item}
          {index !== items.length - 1 && (
            <span className="breadcrumb-separator"> / </span>
          )}
        </span>
      ))}
    </div>
  )
}