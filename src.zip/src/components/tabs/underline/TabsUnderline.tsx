import { useState } from "react";
import "./tabs.underline.scss";
type TabItem = {
  label: string;
  value: string;
};

type Props = {
  tabs: TabItem[];
};
export default function TabsUnderline({ tabs }: Props) {
  const [active, setActive] = useState(tabs[0]?.value);

  return (
    <div className="tabs-underline">
      {tabs.map((tab) => (
        <button
          key={tab.value}
          className={`tab ${active === tab.value ? "active" : ""}`}
          onClick={() => setActive(tab.value)}
        >
          {tab.label}
        </button>
      ))}
    </div>
  );
}