import { useState } from "react";
import "./tabs.soft.scss";

type TabItem = {
  label: string;
  value: string;
  icon?: React.ReactNode;
};

export default function TabsSoft({ tabs }: { tabs: TabItem[] }) {
  const [active, setActive] = useState(tabs[0]?.value);

  return (
    <div className="tabs-soft">
      {tabs.map((tab) => (
        <button
          key={tab.value}
          className={`tab ${active === tab.value ? "active" : ""}`}
          onClick={() => setActive(tab.value)}
        >
          {tab.icon && <span className="icon">{tab.icon}</span>}
          {tab.label}
        </button>
      ))}
    </div>
  );
}