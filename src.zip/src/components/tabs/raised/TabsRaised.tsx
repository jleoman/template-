import { useState } from "react";
import "./tabs.raised.scss";

type TabItem = {
  label: string;
  value: string;
};

type Props = {
  tabs: TabItem[];
};

export default function TabsRaised({ tabs }: Props) {
  const [active, setActive] = useState<string>(tabs[0]?.value);

  return (
    <div className="tabs-raised">
      {tabs.map((tab: TabItem) => (
        <button
          key={tab.value}
          className={`tab ${active === tab.value ? "active" : ""}`}
          onClick={() => setActive(tab.value)}
        >
          {tab.label}
        </button>
      ))}
    </div>
  );
}