interface TablePaginationProps {
  currentPage: number      // Page we're on (1, 2, 3...)
  totalPages: number       // Total pages (10, 20...)
  onPageChange: (page: number) => void  // Called when click page number
  pageSize?: number        // Rows per page (default 10)
  onPageSizeChange?: (size: number) => void  // Change rows per page
  totalItems: number       // Total rows (for showing "1-10 of 100")
}

export default function TablePagination({
  currentPage,
  totalPages,
  onPageChange,
  pageSize = 10,
  onPageSizeChange,
  totalItems
}: TablePaginationProps) {

  // Generate page numbers to show (like: 1, 2, 3, ..., 10)
  const getPageNumbers = () => {
    const pages: (number | string)[] = []
    
    if (totalPages <= 7) {
      // Show all pages if less than 7
      for (let i = 1; i <= totalPages; i++) pages.push(i)
    } else {
      // Show first, last, current, and neighbors
      if (currentPage <= 3) {
        pages.push(1, 2, 3, 4, '...', totalPages)
      } else if (currentPage >= totalPages - 2) {
        pages.push(1, '...', totalPages - 3, totalPages - 2, totalPages - 1, totalPages)
      } else {
        pages.push(1, '...', currentPage - 1, currentPage, currentPage + 1, '...', totalPages)
      }
    }
    
    return pages
  }

  const startItem = (currentPage - 1) * pageSize + 1
  const endItem = Math.min(currentPage * pageSize, totalItems)

  return (
    <div className="table-pagination">
      
      {/* Left: Showing X of Y */}
      <div className="pagination-info">
        Showing <strong>{startItem}-{endItem}</strong> of <strong>{totalItems}</strong>
      </div>

      {/* Middle: Page numbers */}
      <div className="pagination-pages">
        {/* Previous button */}
        <button 
          className="page-btn"
          disabled={currentPage === 1}
          onClick={() => onPageChange(currentPage - 1)}
        >
          ← Prev
        </button>

        {/* Page numbers */}
        {getPageNumbers().map((page, index) => (
          page === '...' ? (
            <span key={index} className="page-ellipsis">...</span>
          ) : (
            <button
              key={index}
              className={`page-btn ${currentPage === page ? 'active' : ''}`}
              onClick={() => onPageChange(page as number)}
            >
              {page}
            </button>
          )
        ))}

        {/* Next button */}
        <button 
          className="page-btn"
          disabled={currentPage === totalPages}
          onClick={() => onPageChange(currentPage + 1)}
        >
          Next →
        </button>
      </div>

      {/* Right: Rows per page selector */}
      {onPageSizeChange && (
        <div className="pagination-size">
          <span>Rows per page:</span>
          <select 
            value={pageSize} 
            onChange={(e) => onPageSizeChange(Number(e.target.value))}
          >
            <option value={10}>10</option>
            <option value={25}>25</option>
            <option value={50}>50</option>
            <option value={100}>100</option>
          </select>
        </div>
      )}
    </div>
  )
}