interface EmptyStateProps {
  title?: string
  description?: string
  actionLabel?: string
  onAction?: () => void
  searchQuery?: string
}

export default function EmptyState({
  title = "No data found",
  description = "Get started by creating your first item",
  actionLabel = "Create New",
  onAction,
  searchQuery
}: EmptyStateProps) {
  
  // Different message if searching
  if (searchQuery) {
    title = "No results found"
    description = `We couldn't find any matches for "${searchQuery}"`
  }

  return (
    <div className="empty-state">
      {/* SVG Illustration */}
      <div className="empty-illustration">
        <svg viewBox="0 0 200 200" fill="none" xmlns="http://www.w3.org/2000/svg">
          <circle cx="100" cy="100" r="80" fill="#F3F4F6"/>
          <rect x="60" y="80" width="80" height="60" rx="8" fill="#E5E7EB"/>
          <rect x="70" y="95" width="60" height="8" rx="4" fill="#9CA3AF"/>
          <rect x="70" y="110" width="40" height="8" rx="4" fill="#D1D5DB"/>
          <circle cx="140" cy="60" r="20" fill="#FDE8DC"/>
          <text x="140" y="65" textAnchor="middle" fill="#F97316" fontSize="20">?</text>
        </svg>
      </div>
      
      <h3>{title}</h3>
      <p>{description}</p>
      
      {onAction && !searchQuery && (
        <button className="btn-empty-action" onClick={onAction}>
          <svg width="20" height="20" viewBox="0 0 20 20" fill="currentColor">
            <path fillRule="evenodd" d="M10 3a1 1 0 011 1v5h5a1 1 0 110 2h-5v5a1 1 0 11-2 0v-5H4a1 1 0 110-2h5V4a1 1 0 011-1z" clipRule="evenodd" />
          </svg>
          {actionLabel}
        </button>
      )}
      
      {searchQuery && (
        <button className="btn-clear-search" onClick={() => window.location.reload()}>
          Clear Search
        </button>
      )}
    </div>
  )
}