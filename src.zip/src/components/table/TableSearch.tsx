import { useState } from "react"

interface TableSearchProps {
  onSearch: (query: string) => void
  placeholder?: string
}

export default function TableSearch({ 
  onSearch, 
  placeholder = "Search..."
}: TableSearchProps) {
  
  const [value, setValue] = useState("")

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newValue = e.target.value
    setValue(newValue)
    onSearch(newValue)
  }

  const handleClear = () => {
    setValue("")
    onSearch("")
  }

  return (
    <div className="table-search">
      <img className="s-icon"  src=" src/assets/icons/search.svg" alt="Search icon for querying table data" />
      <input
        type="text"
        value={value}
        onChange={handleChange}
        placeholder={placeholder}
        className="search-input"
      />
      {value && (
        <button className="clear-btn" onClick={handleClear}>
          ✕
        </button>
      )}
    </div>
  )
}