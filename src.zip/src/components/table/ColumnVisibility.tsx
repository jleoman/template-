import { useState, useRef, useEffect } from "react"

interface ColumnVisibilityProps {
  columns: { key: string; title: string }[]
  visibleColumns: string[]
  onChange: (visibleKeys: string[]) => void
}

export default function ColumnVisibility({
  columns,
  visibleColumns,
  onChange
}: ColumnVisibilityProps) {
  
  const [isOpen, setIsOpen] = useState(false)
  const dropdownRef = useRef<HTMLDivElement>(null)

  // Close on click outside
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target as Node)) {
        setIsOpen(false)
      }
    }
    document.addEventListener("mousedown", handleClickOutside)
    return () => document.removeEventListener("mousedown", handleClickOutside)
  }, [])

  const toggleColumn = (key: string) => {
    const newVisible = visibleColumns.includes(key)
      ? visibleColumns.filter(k => k !== key)
      : [...visibleColumns, key]
    
    // Ensure at least one column visible
    if (newVisible.length > 0) {
      onChange(newVisible)
    }
  }

  const selectAll = () => onChange(columns.map(c => c.key))
  const selectNone = () => onChange([columns[0].key]) // Keep first

  return (
    <div className="column-visibility" ref={dropdownRef}>
      <button 
        className="visibility-toggle"
        onClick={() => setIsOpen(!isOpen)}
      >
        <svg width="16" height="16" viewBox="0 0 20 20" fill="currentColor">
          <path d="M10 12a2 2 0 100-4 2 2 0 000 4z" />
          <path fillRule="evenodd" d="M.458 10C1.732 5.943 5.522 3 10 3s8.268 2.943 9.542 7c-1.274 4.057-5.064 7-9.542 7S1.732 14.057.458 10zM14 10a4 4 0 11-8 0 4 4 0 018 0z" clipRule="evenodd" />
        </svg>
        Columns
      </button>

      {isOpen && (
        <div className="visibility-dropdown">
          <div className="visibility-header">
            <span>Show Columns</span>
            <div className="visibility-actions">
              <button onClick={selectAll}>All</button>
              <button onClick={selectNone}>None</button>
            </div>
          </div>
          
          <div className="visibility-list">
            {columns.map(col => (
              <label key={col.key} className="visibility-item">
                <input
                  type="checkbox"
                  checked={visibleColumns.includes(col.key)}
                  onChange={() => toggleColumn(col.key)}
                />
                <span>{col.title}</span>
              </label>
            ))}
          </div>
        </div>
      )}
    </div>
  )
}