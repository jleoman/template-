import { useState, useMemo, useEffect } from "react"
import TableToolbar from "./TableToolbar"
import TablePagination from "./TablePagination"
import DeleteConfirm from "./DeleteConfirm"
import ColumnVisibility from "./ColumnVisibility"
import TableSkeleton from "./TableSkeleton"
import EmptyState from "./EmptyState"
import DraggableTable from "./DraggableTable"
import ResizableHeader from "./ResizableHeader"

// ============================================
// TYPES
// ============================================

interface TableColumn {
  key: string
  title: string
  width?: string
  sortable?: boolean
  render?: (value: any, row: any) => React.ReactNode
}

interface Tab {
  label: string
  value: string
  count?: number
}

interface TableProps {
  columns: TableColumn[]
  data: any[]
  emptyText?: string
  showCheckbox?: boolean
  onRowSelect?: (selectedRows: any[]) => void
  actions?: (row: any) => React.ReactNode  // Custom actions render function
  showToolbar?: boolean
  searchPlaceholder?: string
  exportFilename?: string
  toolbarExtra?: React.ReactNode
  tabs?: Tab[]
  filterKey?: string
  pagination?: boolean
  pageSize?: number
  expandable?: boolean
  expandContent?: (row: any) => React.ReactNode
  stickyHeader?: boolean
  dynamicPageSize?: boolean
  
  // Delete functionality
  onDelete?: (ids: string[], reason: string) => void
  deleteIdKey?: string
  
  // New features
  isLoading?: boolean
  onCreate?: () => void
  enableDragDrop?: boolean
  enableColumnResize?: boolean
}

// ============================================
// TABLE COMPONENT
// ============================================

export default function Table({ 
  columns: initialColumns,
  data: initialData,
  emptyText = "No data found",
  showCheckbox = false,
  onRowSelect,
  actions,                                    // Actions render function
  showToolbar = false,
  searchPlaceholder = "Search...",
  exportFilename = "export",
  toolbarExtra,
  tabs,
  filterKey,
  pagination = false,
  pageSize: defaultPageSize = 10,
  expandable = false,
  expandContent,
  stickyHeader = true,
  dynamicPageSize = true,
  onDelete,
  deleteIdKey = "id",
  isLoading = false,
  onCreate,
  enableDragDrop = false,
  enableColumnResize = false
}: TableProps) {

  // --- STATE ---
  const [sortKey, setSortKey] = useState<string>("")
  const [sortOrder, setSortOrder] = useState<"asc" | "desc">("asc")
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set())
  const [searchQuery, setSearchQuery] = useState("")
  const [activeTab, setActiveTab] = useState(tabs?.[0]?.value || "all")
  const [currentPage, setCurrentPage] = useState(1)
  const [pageSize, setPageSize] = useState(defaultPageSize)
  const [expandedRows, setExpandedRows] = useState<Set<string>>(new Set())
  
  // Delete state
  const [deleteModalOpen, setDeleteModalOpen] = useState(false)
  const [rowsToDelete, setRowsToDelete] = useState<any[]>([])
  const [singleDeleteName, setSingleDeleteName] = useState("")
  
  // Column visibility
  const [visibleColumnKeys, setVisibleColumnKeys] = useState(
    initialColumns.map(c => c.key)
  )
  
  // Column widths
  const [columnWidths, setColumnWidths] = useState<Record<string, number>>({})
  
  // Data for drag-drop
  const [tableData, setTableData] = useState(initialData)

  // Update data when prop changes
  useEffect(() => {
    setTableData(initialData)
  }, [initialData])

  // --- DYNAMIC PAGE SIZE ---
  useEffect(() => {
    if (!dynamicPageSize || !pagination) return
    const calculateRows = () => {
      const toolbarHeight = 140
      const paginationHeight = 60
      const headerHeight = 50
      const otherElements = 200
      const availableHeight = window.innerHeight - toolbarHeight - paginationHeight - headerHeight - otherElements
      const estimatedRowHeight = 55
      const calculatedRows = Math.max(5, Math.floor(availableHeight / estimatedRowHeight))
      setPageSize(calculatedRows)
    }
    calculateRows()
    window.addEventListener('resize', calculateRows)
    return () => window.removeEventListener('resize', calculateRows)
  }, [dynamicPageSize, pagination])

  // --- FILTER DATA ---
  const filteredData = useMemo(() => {
    let result = [...tableData]
    
    if (tabs && filterKey && activeTab !== "all") {
      result = result.filter(row => row[filterKey] === activeTab)
    }
    
    if (searchQuery) {
      const query = searchQuery.toLowerCase()
      result = result.filter(row => {
        return initialColumns.some(col => {
          const value = String(row[col.key] || "").toLowerCase()
          return value.includes(query)
        })
      })
    }
    
    return result
  }, [tableData, searchQuery, initialColumns, activeTab, tabs, filterKey])

  // --- SORTING ---
  const sortedData = useMemo(() => {
    if (!sortKey) return filteredData
    return [...filteredData].sort((a, b) => {
      const aVal = a[sortKey]
      const bVal = b[sortKey]
      if (aVal < bVal) return sortOrder === "asc" ? -1 : 1
      if (aVal > bVal) return sortOrder === "asc" ? 1 : -1
      return 0
    })
  }, [filteredData, sortKey, sortOrder])

  // --- PAGINATION ---
  const totalPages = Math.ceil(sortedData.length / pageSize)
  const paginatedData = useMemo(() => {
    if (!pagination) return sortedData
    const start = (currentPage - 1) * pageSize
    return sortedData.slice(start, start + pageSize)
  }, [sortedData, currentPage, pageSize, pagination])

  // Reset page on filter change
  useEffect(() => {
    setCurrentPage(1)
    setExpandedRows(new Set())
  }, [searchQuery, activeTab, pageSize])

  // Filter visible columns
  const visibleColumns = useMemo(() => 
    initialColumns.filter(col => visibleColumnKeys.includes(col.key)),
    [initialColumns, visibleColumnKeys]
  )

  // --- HANDLERS ---
  const handleSort = (key: string) => {
    if (sortKey === key) {
      setSortOrder(sortOrder === "asc" ? "desc" : "asc")
    } else {
      setSortKey(key)
      setSortOrder("asc")
    }
  }

  const toggleSelectAll = () => {
    const pageIds = new Set(paginatedData.map((_, i) => String(i)))
    if (selectedIds.size === pageIds.size && pageIds.size > 0) {
      setSelectedIds(new Set())
      onRowSelect?.([])
    } else {
      setSelectedIds(pageIds)
      onRowSelect?.(paginatedData)
    }
  }

  const toggleSelectRow = (index: number, row: any) => {
    const newSelected = new Set(selectedIds)
    const id = String(index)
    if (newSelected.has(id)) newSelected.delete(id)
    else newSelected.add(id)
    setSelectedIds(newSelected)
    const selectedRows = paginatedData.filter((_, i) => newSelected.has(String(i)))
    onRowSelect?.(selectedRows)
  }

  const toggleExpand = (index: number) => {
    const newExpanded = new Set(expandedRows)
    const id = String(index)
    if (newExpanded.has(id)) newExpanded.delete(id)
    else newExpanded.add(id)
    setExpandedRows(newExpanded)
  }

  const handlePageSizeChange = (newSize: number) => {
    setPageSize(newSize)
    setCurrentPage(1)
  }

  // --- DELETE HANDLERS ---
  const handleSingleDelete = (row: any) => {
    setRowsToDelete([row])
    setSingleDeleteName(row.name || row[deleteIdKey] || "this item")
    setDeleteModalOpen(true)
  }

  const handleBulkDelete = () => {
    const selectedRows = paginatedData.filter((_, i) => selectedIds.has(String(i)))
    setRowsToDelete(selectedRows)
    setSingleDeleteName("")
    setDeleteModalOpen(true)
  }

  const confirmDelete = (reason: string) => {
    const ids = rowsToDelete.map(row => row[deleteIdKey])
    onDelete?.(ids, reason)
    setSelectedIds(new Set())
    onRowSelect?.([])
    setDeleteModalOpen(false)
    setRowsToDelete([])
  }

  const cancelDelete = () => {
    setDeleteModalOpen(false)
    setRowsToDelete([])
    setSingleDeleteName("")
  }

  // --- DEFAULT ACTIONS RENDERER ---
  // If no custom actions provided, use default Edit/Delete
  const renderActions = (row: any) => {
    if (actions) {
      return actions(row)  // Use custom actions
    }
    
    // Default actions
    return (
      <div className="action-buttons">
        <button className="btn-action btn-edit">Edit</button>
        <button 
          className="btn-action btn-delete"
          onClick={() => handleSingleDelete(row)}
        >
          Delete
        </button>
      </div>
    )
  }

  const selectedRowsCount = selectedIds.size

  // --- RENDER: LOADING ---
  if (isLoading) {
    return (
      <div className="table-container">
        <TableSkeleton 
          columns={initialColumns.length}
          rows={5}
          showCheckbox={showCheckbox}
          showActions={true}
        />
      </div>
    )
  }

  // --- RENDER: EMPTY ---
  if (tableData.length === 0) {
    return (
      <div className="table-container">
        {showToolbar && (
          <TableToolbar
            tabs={tabs}
            activeTab={activeTab}
            onTabChange={setActiveTab}
            searchPlaceholder={searchPlaceholder}
            onSearch={setSearchQuery}
            data={[]}
            columns={initialColumns.map(c => ({ key: c.key, title: c.title }))}
            filename={exportFilename}
            extraActions={
              <>
                <ColumnVisibility
                  columns={initialColumns.map(c => ({ key: c.key, title: c.title }))}
                  visibleColumns={visibleColumnKeys}
                  onChange={setVisibleColumnKeys}
                />
                {toolbarExtra}
              </>
            }
          />
        )}
        <EmptyState 
          searchQuery={searchQuery}
          onAction={onCreate}
        />
      </div>
    )
  }

  // --- RENDER: TABLE ---
  return (
    <>
      <div className={`table-container ${showToolbar ? 'table-with-toolbar' : ''} ${selectedRowsCount > 0 ? 'has-bulk-actions' : ''}`}>
        
        {/* BULK ACTIONS BAR - FIXED BOTTOM */}
        {showCheckbox && selectedRowsCount > 0 && (
          <div className="bulk-actions-bar fixed-bottom">
            <div className="bulk-actions-content">
              <span className="selected-count">
                {selectedRowsCount} {selectedRowsCount === 1 ? 'item' : 'items'} selected
              </span>
              <div className="bulk-actions">
                <button className="btn-bulk-export">
                  <svg width="16" height="16" viewBox="0 0 20 20" fill="currentColor">
                    <path fillRule="evenodd" d="M3 17a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zm3.293-7.707a1 1 0 011.414 0L9 10.586V3a1 1 0 112 0v7.586l1.293-1.293a1 1 0 111.414 1.414l-3 3a1 1 0 01-1.414 0l-3-3a1 1 0 010-1.414z" clipRule="evenodd" />
                  </svg>
                  Export
                </button>
                <button className="btn-bulk-delete" onClick={handleBulkDelete}>
                  <svg width="16" height="16" viewBox="0 0 20 20" fill="currentColor">
                    <path fillRule="evenodd" d="M9 2a1 1 0 00-.894.553L7.382 4H4a1 1 0 000 2v10a2 2 0 002 2h8a2 2 0 002-2V6a1 1 0 100-2h-3.382l-.724-1.447A1 1 0 0011 2H9zM7 8a1 1 0 012 0v6a1 1 0 11-2 0V8zm5-1a1 1 0 00-1 1v6a1 1 0 102 0V8a1 1 0 00-1-1z" clipRule="evenodd" />
                  </svg>
                  Delete
                </button>
              </div>
            </div>
          </div>
        )}

        {/* TOOLBAR */}
        {showToolbar && (
          <TableToolbar
            tabs={tabs}
            activeTab={activeTab}
            onTabChange={setActiveTab}
            searchPlaceholder={searchPlaceholder}
            onSearch={setSearchQuery}
            data={filteredData}
            columns={visibleColumns.map(c => ({ key: c.key, title: c.title }))}
            filename={exportFilename}
            extraActions={
              <>
                <ColumnVisibility
                  columns={initialColumns.map(c => ({ key: c.key, title: c.title }))}
                  visibleColumns={visibleColumnKeys}
                  onChange={setVisibleColumnKeys}
                />
                {toolbarExtra}
              </>
            }
          />
        )}

        {/* TABLE */}
        <div className="table-wrapper">
          <table className="data-table">
            
            <thead className={stickyHeader ? 'sticky-header' : ''}>
              <tr>
                {enableDragDrop && <th className="drag-cell"></th>}
                
                {showCheckbox && (
                  <th className="checkbox-cell">
                    <input 
                      type="checkbox"
                      checked={selectedIds.size === paginatedData.length && paginatedData.length > 0}
                      onChange={toggleSelectAll}
                    />
                  </th>
                )}
                
                {expandable && <th className="expand-cell"></th>}

                {visibleColumns.map(col => (
                  enableColumnResize ? (
                    <ResizableHeader
                      key={col.key}
                      width={columnWidths[col.key] || (col.width ? parseInt(col.width) : 150)}
                      onResize={(w) => setColumnWidths(prev => ({ ...prev, [col.key]: w }))}
                    >
                      <span 
                        className={col.sortable ? 'sortable' : ''}
                        onClick={() => col.sortable && handleSort(col.key)}
                      >
                        {col.title}
                        {col.sortable && sortKey === col.key && (
                          <span className="sort-arrow">
                            {sortOrder === "asc" ? " ▲" : " ▼"}
                          </span>
                        )}
                      </span>
                    </ResizableHeader>
                  ) : (
                    <th 
                      key={col.key} 
                      style={{ width: col.width }}
                      className={col.sortable ? 'sortable' : ''}
                      onClick={() => col.sortable && handleSort(col.key)}
                    >
                      {col.title}
                      {col.sortable && sortKey === col.key && (
                        <span className="sort-arrow">
                          {sortOrder === "asc" ? " ▲" : " ▼"}
                        </span>
                      )}
                    </th>
                  )
                ))}

                {/* ACTIONS COLUMN HEADER */}
                <th className="actions-cell">Actions</th>
              </tr>
            </thead>

            {/* TABLE BODY */}
            {enableDragDrop ? (
              <DraggableTable
                data={paginatedData}
                columns={visibleColumns}
                onReorder={setTableData}
                showCheckbox={showCheckbox}
                selectedIds={selectedIds}
                onSelect={toggleSelectRow}
                actions={renderActions}  // Pass actions here
                expandable={expandable}
                expandedRows={expandedRows}
                onExpand={toggleExpand}
                expandContent={expandContent}
              />
            ) : (
              <tbody>
                {paginatedData.length === 0 ? (
                  <tr>
                    <td 
                      colSpan={visibleColumns.length + (showCheckbox ? 1 : 0) + 1 + (expandable ? 1 : 0) + (enableDragDrop ? 1 : 0)} 
                      className="empty-cell"
                    >
                      {searchQuery ? "No matching results" : emptyText}
                    </td>
                  </tr>
                ) : (
                  paginatedData.map((row, index) => (
                    <>
                      {/* MAIN ROW */}
                      <tr 
                        key={index}
                        className={`${selectedIds.has(String(index)) ? 'selected' : ''} ${expandedRows.has(String(index)) ? 'expanded' : ''}`}
                      >
                        {enableDragDrop && (
                          <td className="drag-cell">
                            <svg width="16" height="16" viewBox="0 0 20 20" fill="currentColor">
                              <path d="M7 2a2 2 0 1 0 .001 4.001A2 2 0 0 0 7 2zm0 6a2 2 0 1 0 .001 4.001A2 2 0 0 0 7 8zm0 6a2 2 0 1 0 .001 4.001A2 2 0 0 0 7 14zm6-8a2 2 0 1 0-.001-4.001A2 2 0 0 0 13 6zm0 2a2 2 0 1 0 .001 4.001A2 2 0 0 0 13 8zm0 6a2 2 0 1 0 .001 4.001A2 2 0 0 0 13 14z"/>
                            </svg>
                          </td>
                        )}

                        {showCheckbox && (
                          <td className="checkbox-cell">
                            <input
                              type="checkbox"
                              checked={selectedIds.has(String(index))}
                              onChange={() => toggleSelectRow(index, row)}
                            />
                          </td>
                        )}

                        {expandable && (
                          <td className="expand-cell">
                            <button 
                              className="expand-btn"
                              onClick={() => toggleExpand(index)}
                            >
                              {expandedRows.has(String(index)) ? '▼' : '▶'}
                            </button>
                          </td>
                        )}

                        {visibleColumns.map(col => (
                          <td 
                            key={col.key} 
                            onClick={() => expandable && toggleExpand(index)}
                          >
                            {col.render ? col.render(row[col.key], row) : row[col.key]}
                          </td>
                        ))}

                        {/* ACTIONS CELL - THIS IS THE KEY FIX */}
                        <td className="actions-cell">
                          {renderActions(row)}
                        </td>
                      </tr>

                      {/* EXPANDED CONTENT */}
                      {expandable && expandedRows.has(String(index)) && expandContent && (
                        <tr className="expanded-content-row">
                          <td 
                            colSpan={visibleColumns.length + (showCheckbox ? 1 : 0) + 1 + (expandable ? 1 : 0) + (enableDragDrop ? 1 : 0)} 
                            className="expanded-content"
                          >
                            <div className="expanded-inner">
                              {expandContent(row)}
                            </div>
                          </td>
                        </tr>
                      )}
                    </>
                  ))
                )}
              </tbody>
            )}

          </table>
        </div>

        {/* PAGINATION */}
        {pagination && (
          <div className="pagination-wrapper">
            <TablePagination
              currentPage={currentPage}
              totalPages={totalPages}
              onPageChange={setCurrentPage}
              pageSize={pageSize}
              onPageSizeChange={handlePageSizeChange}
              totalItems={sortedData.length}
            />
          </div>
        )}

      </div>

      {/* DELETE CONFIRMATION MODAL */}
      <DeleteConfirm
        isOpen={deleteModalOpen}
        onClose={cancelDelete}
        onConfirm={confirmDelete}
        count={rowsToDelete.length}
        itemName={singleDeleteName}
      />
    </>
  )
}