import { useState } from "react"

interface DeleteConfirmProps {
  isOpen: boolean
  onClose: () => void
  onConfirm: (reason: string) => void
  count: number  // How many rows being deleted
  itemName?: string  // Name of single item (optional)
}

export default function DeleteConfirm({
  isOpen,
  onClose,
  onConfirm,
  count,
  itemName
}: DeleteConfirmProps) {
  
  const [reason, setReason] = useState("")
  const [error, setError] = useState("")

  const handleConfirm = () => {
    if (!reason.trim()) {
      setError("Please enter a reason for deletion")
      return
    }
    onConfirm(reason)
    setReason("") // Reset for next time
    setError("")
  }

  const handleClose = () => {
    setReason("")
    setError("")
    onClose()
  }

  if (!isOpen) return null

  return (
    <div className="delete-confirm-overlay" onClick={handleClose}>
      <div className="delete-confirm-modal" onClick={(e) => e.stopPropagation()}>
        
        {/* Header */}
        <div className="delete-confirm-header">
          <div className="warning-icon">⚠️</div>
          <h3>Confirm Delete</h3>
        </div>

        {/* Message */}
        <div className="delete-confirm-body">
          {count === 1 ? (
            <p>Are you sure you want to delete <strong>{itemName || "this item"}</strong>?</p>
          ) : (
            <p>Are you sure you want to delete <strong>{count} items</strong>?</p>
          )}
          
          <p className="warning-text">This action cannot be undone.</p>

          {/* Reason Field */}
          <div className="reason-field">
            <label htmlFor="delete-reason">
              Reason for deletion <span className="required">*</span>
            </label>
            <textarea
              id="delete-reason"
              value={reason}
              onChange={(e) => {
                setReason(e.target.value)
                setError("")
              }}
              placeholder="Enter reason for deleting..."
              rows={3}
              autoFocus
            />
            {error && <span className="error-text">{error}</span>}
          </div>
        </div>

        {/* Buttons */}
        <div className="delete-confirm-footer">
          <button className="btn-cancel" onClick={handleClose}>
            Cancel
          </button>
          <button className="btn-delete-confirm" onClick={handleConfirm}>
            Delete {count > 1 ? `${count} Items` : "Item"}
          </button>
        </div>

      </div>
    </div>
  )
}