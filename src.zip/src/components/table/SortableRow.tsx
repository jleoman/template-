import { useSortable } from "@dnd-kit/sortable"
import { CSS } from "@dnd-kit/utilities"

interface SortableRowProps {
  row: any
  index: number
  columns: any[]
  showCheckbox?: boolean
  isSelected?: boolean
  onSelect?: () => void
  actions?: (row: any) => React.ReactNode
  expandable?: boolean
  isExpanded?: boolean
  onExpand?: () => void
  expandContent?: (row: any) => React.ReactNode
}

export default function SortableRow({
  row,
  index,
  columns,
  showCheckbox,
  isSelected,
  onSelect,
  actions,
  expandable,
  isExpanded,
  onExpand,
  expandContent
}: SortableRowProps) {
  
  const {
    attributes,
    listeners,
    setNodeRef,
    transform,
    transition,
    isDragging
  } = useSortable({ id: row.id || index })

  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
    opacity: isDragging ? 0.5 : 1,
    background: isDragging ? "#f3f4f6" : undefined
  }

  return (
    <>
      <tr 
        ref={setNodeRef}
        style={style}
        className={`${isSelected ? 'selected' : ''} ${isExpanded ? 'expanded' : ''} ${isDragging ? 'dragging' : ''}`}
      >
        {/* Drag Handle */}
        <td className="drag-cell" {...attributes} {...listeners}>
          <svg width="16" height="16" viewBox="0 0 20 20" fill="currentColor">
            <path d="M7 2a2 2 0 1 0 .001 4.001A2 2 0 0 0 7 2zm0 6a2 2 0 1 0 .001 4.001A2 2 0 0 0 7 8zm0 6a2 2 0 1 0 .001 4.001A2 2 0 0 0 7 14zm6-8a2 2 0 1 0-.001-4.001A2 2 0 0 0 13 6zm0 2a2 2 0 1 0 .001 4.001A2 2 0 0 0 13 8zm0 6a2 2 0 1 0 .001 4.001A2 2 0 0 0 13 14z"/>
          </svg>
        </td>

        {showCheckbox && (
          <td className="checkbox-cell">
            <input type="checkbox" checked={isSelected} onChange={onSelect} />
          </td>
        )}

        {expandable && (
          <td className="expand-cell">
            <button className="expand-btn" onClick={onExpand}>
              {isExpanded ? '▼' : '▶'}
            </button>
          </td>
        )}

        {columns.map(col => (
          <td key={col.key} onClick={expandable ? onExpand : undefined}>
            {col.render ? col.render(row[col.key], row) : row[col.key]}
          </td>
        ))}

        {actions && <td className="actions-cell">{actions(row)}</td>}
      </tr>

      {expandable && isExpanded && expandContent && (
        <tr className="expanded-content-row">
          <td colSpan={100} className="expanded-content">
            <div className="expanded-inner">{expandContent(row)}</div>
          </td>
        </tr>
      )}
    </>
  )
}