import { useState, useRef, useCallback } from "react"

interface ResizableHeaderProps {
  children: React.ReactNode
  width?: number
  onResize: (width: number) => void
  minWidth?: number
  maxWidth?: number
}

export default function ResizableHeader({
  children,
  width = 150,
  onResize,
  minWidth = 80,
  maxWidth = 500
}: ResizableHeaderProps) {
  
  const [isResizing, setIsResizing] = useState(false)
  const startX = useRef(0)
  const startWidth = useRef(width)

  const handleMouseDown = useCallback((e: React.MouseEvent) => {
    setIsResizing(true)
    startX.current = e.clientX
    startWidth.current = width
    
    const handleMouseMove = (e: MouseEvent) => {
      const diff = e.clientX - startX.current
      const newWidth = Math.max(minWidth, Math.min(maxWidth, startWidth.current + diff))
      onResize(newWidth)
    }
    
    const handleMouseUp = () => {
      setIsResizing(false)
      document.removeEventListener("mousemove", handleMouseMove)
      document.removeEventListener("mouseup", handleMouseUp)
    }
    
    document.addEventListener("mousemove", handleMouseMove)
    document.addEventListener("mouseup", handleMouseUp)
  }, [width, onResize, minWidth, maxWidth])

  return (
    <th 
      className={`resizable-header ${isResizing ? 'resizing' : ''}`}
      style={{ width }}
    >
      <div className="header-content">{children}</div>
      <div 
        className="resize-handle"
        onMouseDown={handleMouseDown}
      />
    </th>
  )
}