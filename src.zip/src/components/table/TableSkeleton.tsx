interface TableSkeletonProps {
  columns: number      // Number of columns
  rows?: number        // Number of skeleton rows (default 5)
  showCheckbox?: boolean
  showActions?: boolean
}

export default function TableSkeleton({
  columns,
  rows = 5,
  showCheckbox,
  showActions
}: TableSkeletonProps) {
  
  const totalCols = columns + (showCheckbox ? 1 : 0) + (showActions ? 1 : 0)

  return (
    <div className="table-skeleton">
      {/* Header skeleton */}
      <div className="skeleton-header">
        {showCheckbox && <div className="skeleton-cell skeleton-checkbox" />}
        {Array.from({ length: columns }).map((_, i) => (
          <div key={i} className="skeleton-cell skeleton-th" style={{ width: `${20 + Math.random() * 30}%` }} />
        ))}
        {showActions && <div className="skeleton-cell skeleton-actions" />}
      </div>

      {/* Row skeletons */}
      {Array.from({ length: rows }).map((_, rowIndex) => (
        <div key={rowIndex} className="skeleton-row">
          {showCheckbox && <div className="skeleton-cell skeleton-checkbox" />}
          {Array.from({ length: columns }).map((_, colIndex) => (
            <div key={colIndex} className="skeleton-cell skeleton-td" />
          ))}
          {showActions && <div className="skeleton-cell skeleton-actions" />}
        </div>
      ))}
    </div>
  )
}