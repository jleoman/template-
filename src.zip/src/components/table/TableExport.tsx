interface TableExportProps {
  data: any[]
  filename?: string
  columns: { key: string; title: string }[]
}

export default function TableExport({ 
  data, 
  filename = "export",
  columns
}: TableExportProps) {

  const handleExport = () => {
    const headers = columns.map(col => col.title).join(",")
    
    const rows = data.map(row => {
      return columns.map(col => {
        const val = String(row[col.key] || "")
        if (val.includes(",") || val.includes('"')) {
          return `"${val.replace(/"/g, '""')}"`
        }
        return val
      }).join(",")
    })

    const csv = [headers, ...rows].join("\n")
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" })
    const link = document.createElement("a")
    const url = URL.createObjectURL(blob)
    
    link.setAttribute("href", url)
    link.setAttribute("download", `${filename}.csv`)
    link.style.visibility = "hidden"
    
    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link)
  }

  return (
    <button className="btn-export" onClick={handleExport}>
      <svg viewBox="0 0 20 20" fill="currentColor">
        <path fillRule="evenodd" d="M3 17a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zm3.293-7.707a1 1 0 011.414 0L9 10.586V3a1 1 0 112 0v7.586l1.293-1.293a1 1 0 111.414 1.414l-3 3a1 1 0 01-1.414 0l-3-3a1 1 0 010-1.414z" clipRule="evenodd" />
      </svg>
      Export Excel
    </button>
  )
}