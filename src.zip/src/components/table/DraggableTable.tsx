import { DndContext, closestCenter, KeyboardSensor, PointerSensor, useSensor, useSensors } from "@dnd-kit/core"
import { arrayMove, SortableContext, sortableKeyboardCoordinates, verticalListSortingStrategy } from "@dnd-kit/sortable"
import { useState } from "react"
import SortableRow from "./SortableRow"

interface DraggableTableProps {
  data: any[]
  columns: any[]
  onReorder: (newData: any[]) => void
  showCheckbox?: boolean
  selectedIds?: Set<string>
  onSelect?: (index: number, row: any) => void
  actions?: (row: any) => React.ReactNode
  expandable?: boolean
  expandedRows?: Set<string>
  onExpand?: (index: number) => void
  expandContent?: (row: any) => React.ReactNode
}

export default function DraggableTable({
  data,
  columns,
  onReorder,
  showCheckbox,
  selectedIds,
  onSelect,
  actions,
  expandable,
  expandedRows,
  onExpand,
  expandContent
}: DraggableTableProps) {
  
  const sensors = useSensors(
    useSensor(PointerSensor),
    useSensor(KeyboardSensor, { coordinateGetter: sortableKeyboardCoordinates })
  )

  const handleDragEnd = (event: any) => {
    const { active, over } = event
    if (active.id !== over.id) {
      const oldIndex = data.findIndex((_, i) => (data[i].id || String(i)) === active.id)
      const newIndex = data.findIndex((_, i) => (data[i].id || String(i)) === over.id)
      onReorder(arrayMove(data, oldIndex, newIndex))
    }
  }

  return (
    <DndContext sensors={sensors} collisionDetection={closestCenter} onDragEnd={handleDragEnd}>
      <SortableContext items={data.map((row, i) => row.id || String(i))} strategy={verticalListSortingStrategy}>
        <tbody>
          {data.map((row, index) => (
            <SortableRow
              key={row.id || index}
              row={row}
              index={index}
              columns={columns}
              showCheckbox={showCheckbox}
              isSelected={selectedIds?.has(String(index))}
              onSelect={() => onSelect?.(index, row)}
              actions={actions}
              expandable={expandable}
              isExpanded={expandedRows?.has(String(index))}
              onExpand={() => onExpand?.(index)}
              expandContent={expandContent}
            />
          ))}
        </tbody>
      </SortableContext>
    </DndContext>
  )
}