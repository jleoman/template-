import { useState } from "react"

interface ExpandableRowProps {
  row: any                    // The row data
  columns: any[]              // Regular columns
  expandContent: (row: any) => React.ReactNode  // What to show when expanded
  actions?: (row: any) => React.ReactNode
  showCheckbox?: boolean
  isSelected?: boolean
  onSelect?: () => void
}

export default function ExpandableRow({
  row,
  columns,
  expandContent,
  actions,
  showCheckbox,
  isSelected,
  onSelect
}: ExpandableRowProps) {
  
  const [isExpanded, setIsExpanded] = useState(false)

  return (
    <>
      {/* MAIN ROW */}
      <tr className={`expandable-row ${isExpanded ? 'expanded' : ''} ${isSelected ? 'selected' : ''}`}>
        
        {/* Checkbox */}
        {showCheckbox && (
          <td className="checkbox-cell">
            <input type="checkbox" checked={isSelected} onChange={onSelect} />
          </td>
        )}

        {/* Expand/Collapse button column */}
        <td className="expand-cell">
          <button 
            className="expand-btn"
            onClick={() => setIsExpanded(!isExpanded)}
          >
            {isExpanded ? '▼' : '▶'}
          </button>
        </td>

        {/* Regular columns */}
        {columns.map((col) => (
          <td key={col.key} onClick={() => setIsExpanded(!isExpanded)}>
            {col.render ? col.render(row[col.key], row) : row[col.key]}
          </td>
        ))}

        {/* Actions */}
        {actions && <td className="actions-cell">{actions(row)}</td>}
      </tr>

      {/* EXPANDED CONTENT ROW */}
      {isExpanded && (
        <tr className="expanded-content-row">
          <td 
            colSpan={columns.length + (showCheckbox ? 1 : 0) + (actions ? 1 : 0) + 1} 
            className="expanded-content"
          >
            <div className="expanded-inner">
              {expandContent(row)}
            </div>
          </td>
        </tr>
      )}
    </>
  )
}