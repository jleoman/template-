import TableSearch from "./TableSearch"
import TableExport from "./TableExport"

interface Tab {
  label: string
  value: string
  count?: number
}

interface TableToolbarProps {
  tabs?: Tab[]                    // NEW: Tabs to show
  activeTab?: string             // NEW: Which tab is active
  onTabChange?: (value: string) => void  // NEW: Called when tab clicked
  searchPlaceholder?: string
  onSearch: (query: string) => void
  data: any[]
  columns: { key: string; title: string }[]
  filename?: string
  extraActions?: React.ReactNode
}

export default function TableToolbar({
  tabs,
  activeTab,
  onTabChange,
  searchPlaceholder,
  onSearch,
  data,
  columns,
  filename,
  extraActions
}: TableToolbarProps) {
  return (
    <div className="table-toolbar">
      
      {/* LEFT SIDE: Tabs + Search */}
      <div className="toolbar-left">
        
        {/* TABS (if provided) */}
        {tabs && tabs.length > 0 && (
          <div className="toolbar-tabs">
            {tabs.map((tab) => (
              <button
                key={tab.value}
                className={`toolbar-tab ${activeTab === tab.value ? 'active' : ''}`}
                onClick={() => onTabChange?.(tab.value)}
              >
                {tab.label}
                {tab.count !== undefined && tab.count > 0 && (
                  <span className="toolbar-tab-badge">{tab.count}</span>
                )}
              </button>
            ))}
          </div>
        )}

        {/* SEARCH BOX */}
        <TableSearch 
          onSearch={onSearch}
          placeholder={searchPlaceholder}
        />
      </div>

      {/* RIGHT SIDE: Export + Extra buttons */}
      <div className="toolbar-right">
        {extraActions}
        <TableExport 
          data={data}
          columns={columns}
          filename={filename}
        />
      </div>
    </div>
  )
}