import { Routes, Route } from "react-router-dom"
import AdminLayout from "./layout/AdminLayout"

function App() {

  return (

    <Routes>

      <Route path="/*" element={<AdminLayout />} />

    </Routes>

  )

}

export default App